#' @title Check and report the type of data in `Seurat` object
#'
#' @description
#' Checks and returns a string indicating the type of data.
#' It checks for the presence of infinite values, negative values,
#' and whether the values are floats or integers.
#'
#' @md
#' @inheritParams thisutils::log_message
#' @param object A `Seurat` object or a matrix.
#'
#' @return
#' A string indicating the type of data.
#' Possible values are:
#' `"raw_counts"`, `"log_normalized_counts"`, `"raw_normalized_counts"`, or `"unknown"`.
#'
#' @export
CheckDataType <- function(object, ...) {
  UseMethod(generic = "CheckDataType", object = object)
}

#' @md
#' @inheritParams RunStandardWorkflow
#' @inheritParams FeatureDimPlot
#'
#' @rdname CheckDataType
#' @method CheckDataType Seurat
#' @export
#'
#' @examples
#' data(pancreas_sub)
#' CheckDataType(pancreas_sub)
CheckDataType.Seurat <- function(
  object,
  layer = "data",
  assay = NULL,
  verbose = TRUE,
  ...
) {
  assay <- assay %||% SeuratObject::DefaultAssay(object)
  data <- GetAssayData5(
    object,
    layer = layer,
    assay = assay,
    ...
  )
  CheckDataType(data, verbose = verbose)
}

#' @rdname CheckDataType
#' @method CheckDataType default
#' @export
CheckDataType.default <- function(
  object,
  verbose = TRUE,
  ...
) {
  isfinite <- all(is.finite(range(object, na.rm = TRUE)))
  if (inherits(object, "dgCMatrix")) {
    isfloat <- any(object@x %% 1 != 0, na.rm = TRUE)
  } else {
    isfloat <- any(
      object[, sample(seq_len(ncol(object)), min(ncol(object), 1000))] %% 1 != 0,
      na.rm = TRUE
    )
  }
  islog <- is.finite(expm1(x = max(object, na.rm = TRUE)))
  isnegative <- any(object < 0)

  if (isFALSE(isfinite)) {
    log_message(
      "Infinite values detected",
      message_type = "warning",
      verbose = verbose
    )
    return("unknown")
  } else if (isTRUE(isnegative)) {
    log_message(
      "Negative values detected",
      message_type = "warning",
      verbose = verbose
    )
    return("unknown")
  } else {
    if (!isfloat) {
      log_message(
        "Data type is raw counts",
        verbose = verbose
      )
      return("raw_counts")
    } else if (isfloat && islog) {
      log_message(
        "Data type is log-normalized",
        verbose = verbose
      )
      return("log_normalized_counts")
    } else if (isfloat && !islog) {
      if (isFALSE(isnegative)) {
        log_message(
          "Data type is normalized without log transformation",
          verbose = verbose
        )
        return("raw_normalized_counts")
      } else {
        log_message(
          "Can not determine whether data type is log-normalized",
          message_type = "warning",
          verbose = verbose
        )
        return("unknown")
      }
    }
  }
}

#' @title Check and preprocess a list of `Seurat` objects
#'
#' @description
#' Checks and preprocesses a list of `Seurat` objects.
#' It performs various checks on the input, including verification of input types,
#' assay type consistency, feature name consistency, and batch column consistency.
#' It also performs data normalization and variable feature finding based on the specified parameters.
#' Finally, it prepares the data for integration analysis based on the highly variable features.
#'
#' @md
#' @inheritParams thisutils::log_message
#' @inheritParams RunStandardWorkflow
#' @param srt_list A list of `Seurat` objects to be checked and preprocessed.
#' @param batch Batch variable name.
#' @param do_normalization Whether data normalization should be performed.
#' @param normalization_method The normalization method to be used.
#' Possible values are `"LogNormalize"`, `"SCT"`, `"TFIDF"`, and `"scran"`.
#' @param HVF_source The source of highly variable features.
#' Possible values are `"global"` and `"separate"`.
#' @param HVF_min_intersection The feature needs to be present in batches for a minimum number of times in order to be considered as highly variable.
#' @param vars_to_regress A vector of variable names to include as additional regression variables.
#'
#' @return
#' A list containing the preprocessed `Seurat` objects,
#' the highly variable features, the assay name,
#' and the type of assay.
#'
#' @export
CheckDataList <- function(
  srt_list,
  batch,
  assay = NULL,
  do_normalization = NULL,
  normalization_method = "LogNormalize",
  do_HVF_finding = TRUE,
  HVF_source = "separate",
  HVF_method = "vst",
  nHVF = 2000,
  HVF_min_intersection = 1,
  HVF = NULL,
  vars_to_regress = NULL,
  verbose = TRUE,
  seed = 11
) {
  log_message(
    "Checking a list of {.cls Seurat}...",
    verbose = verbose
  )
  normalization_disabled <- identical(do_normalization, FALSE)
  set.seed(seed)

  if (!inherits(srt_list, "list") || any(sapply(srt_list, function(x) !inherits(x, "Seurat")))) {
    log_message(
      "{.arg srt_list} is not a list of {.cls Seurat}",
      message_type = "error"
    )
  }
  normalization_methods <- c("LogNormalize", "SCT", "TFIDF", "scran")
  if (!normalization_method %in% normalization_methods) {
    log_message(
      "{.arg normalization_method} must be one of: {.val {normalization_methods}}",
      message_type = "error"
    )
  }
  hvf_sources <- c("global", "separate")
  if (!HVF_source %in% hvf_sources) {
    log_message(
      "{.arg HVF_source} must be one of: {.val {hvf_sources}}",
      message_type = "error"
    )
  }
  which_less_2 <- which(sapply(srt_list, ncol) < 2)
  if (length(which_less_2) > 0) {
    log_message(
      "{.cls Seurat} in {.arg srt_list} contain less than 2 cells. {.arg srt_list} index: {.val {which_less_2}}",
      message_type = "error"
    )
  }

  if (is.null(assay)) {
    default_assay <- unique(sapply(srt_list, SeuratObject::DefaultAssay))
    if (length(default_assay) != 1) {
      log_message(
        "The default assay name of {.cls Seurat} in the {.arg srt_list} is inconsistent",
        message_type = "error"
      )
    } else {
      assay <- default_assay
    }
  }

  assay_type <- unique(
    sapply(
      srt_list, function(srt) {
        class(
          Seurat::GetAssay(
            srt,
            assay = assay
          )
        )
      }
    )
  )
  if (length(assay_type) != 1) {
    log_message(
      "The assay type of {.cls Seurat} in the {.arg srt_list} is inconsistent",
      message_type = "error"
    )
  } else {
    if (assay_type == "Assay" || assay_type == "Assay5") {
      type <- "RNA"
    } else if (assay_type == "ChromatinAssay") {
      type <- "Chromatin"
    } else {
      type <- "Unknown"
    }
  }
  if (type != "RNA" && (normalization_method == "scran" || HVF_method == "scran")) {
    log_message(
      "{.pkg scran} normalization and HVF selection are only supported for RNA assays",
      message_type = "error"
    )
  }

  features_list <- lapply(
    srt_list, function(srt) {
      sort(
        rownames(
          Seurat::GetAssay(
            srt,
            assay = assay
          )
        )
      )
    }
  )
  if (length(unique(features_list)) != 1) {
    if (type == "Chromatin") {
      log_message(
        "The peaks in assay {.val {assay}} differ between objects. Aligning to a merged union peak set...",
        message_type = "warning",
        verbose = verbose
      )
      temp_col <- ".scop_align_id"
      while (any(vapply(srt_list, function(srt) temp_col %in% colnames(srt@meta.data), logical(1)))) {
        temp_col <- paste0(temp_col, "_x")
      }
      align_ids <- paste0(".scop_align_", seq_along(srt_list))
      for (i in seq_along(srt_list)) {
        srt_list[[i]][[temp_col]] <- align_ids[[i]]
      }
      srt_merge <- Reduce(merge, srt_list)
      srt_list_aligned <- Seurat::SplitObject(
        object = srt_merge,
        split.by = temp_col
      )
      srt_list <- unname(srt_list_aligned[align_ids])
      for (i in seq_along(srt_list)) {
        if (temp_col %in% colnames(srt_list[[i]]@meta.data)) {
          srt_list[[i]]@meta.data[, temp_col] <- NULL
        }
      }
    } else {
      cf <- Reduce(
        intersect,
        lapply(
          srt_list, function(srt) {
            rownames(
              Seurat::GetAssay(
                srt,
                assay = assay
              )
            )
          }
        )
      )
      log_message(
        "{.arg srt_list} have different feature names! Will subset the common features ({.val {length(cf)}}) for downstream analysis",
        message_type = "warning",
        verbose = verbose
      )
      for (i in seq_along(srt_list)) {
        srt_list[[i]][[assay]] <- subset(srt_list[[i]][[assay]], features = cf)
      }
    }
  }

  celllist <- unlist(lapply(srt_list, colnames))
  if (length(celllist) != length(unique(celllist))) {
    log_message(
      "{.arg srt_list} have duplicated cell names",
      message_type = "error"
    )
  }

  if (length(batch) != 1 && length(batch) != length(srt_list)) {
    log_message(
      "{.arg batch} must be a character to specify the batch column in the meta.data or a vector of the same length of the {.arg srt_list}",
      message_type = "error"
    )
  }
  if (length(batch) == length(srt_list)) {
    srt_list_tmp <- list()
    for (bat in unique(batch)) {
      srt_list_tmp[[bat]] <- Reduce(merge, srt_list[batch == bat])
    }
    srt_list <- srt_list_tmp
  } else {
    if (
      !all(sapply(srt_list, function(x) {
        batch %in% colnames(x@meta.data)
      }))
    ) {
      log_message(
        "batch column ({.val {batch}}) was not found in one or more object of the {.arg srt_list}",
        message_type = "error"
      )
    }
    for (i in seq_along(srt_list)) {
      u <- unique(srt_list[[i]][[batch, drop = TRUE]])
      if (length(u) > 1) {
        x <- Seurat::SplitObject(srt_list[[i]], split.by = batch)
        srt_list[[i]] <- character(0)
        srt_list <- c(srt_list, x)
      }
    }
    srt_list <- srt_list[sapply(srt_list, length) > 0]
    srt_list_batch <- sapply(
      srt_list,
      function(x) unique(x[[batch, drop = TRUE]])
    )
    batch_to_merge <- names(which(table(srt_list_batch) > 1))
    if (length(batch_to_merge) > 0) {
      for (b in batch_to_merge) {
        index <- which(srt_list_batch == b)
        srt_list_tmp <- Reduce(merge, srt_list[index])
        for (i in index) {
          srt_list[[i]] <- character(0)
        }
        srt_list <- c(srt_list, srt_list_tmp)
      }
    }
    srt_list <- srt_list[sapply(srt_list, length) > 0]
  }

  for (i in seq_along(srt_list)) {
    if (!assay %in% SeuratObject::Assays(srt_list[[i]])) {
      log_message(
        "{.arg srt_list} {.val {i}} does not contain {.val {assay}} assay",
        message_type = "error"
      )
    }
    SeuratObject::DefaultAssay(srt_list[[i]]) <- assay
    status <- suppressWarnings(
      CheckDataType(
        srt_list[[i]],
        layer = "data",
        assay = assay,
        verbose = FALSE
      )
    )
    if (status == "log_normalized_counts") {
      log_message(
        "Data {.val {i}}/{.val {length(srt_list)}} of the {.arg srt_list} has been log-normalized",
        verbose = verbose
      )
    } else if (status %in% c("raw_counts", "raw_normalized_counts", "unknown")) {
      log_message(
        "Data {.val {i}}/{.val {length(srt_list)}} of the {.arg srt_list} is {.val {status}}",
        message_type = "warning",
        verbose = verbose
      )
      if (!normalization_disabled) do_normalization <- TRUE
    }
    if (isTRUE(do_normalization)) {
      if (normalization_method == "LogNormalize") {
        log_message(
          "Perform {.fn NormalizeData} with {.arg normalization.method = 'LogNormalize'} on {.val {i}}/{.val {length(srt_list)}} of {.arg srt_list}...",
          verbose = verbose
        )
        srt_list[[i]] <- NormalizeData(
          object = srt_list[[i]],
          assay = assay,
          normalization.method = "LogNormalize",
          verbose = FALSE
        )
      }
      if (normalization_method == "TFIDF") {
        log_message(
          "Perform {.fn RunTFIDF} on {.val {i}}/{.val {length(srt_list)}} of {.arg srt_list}...",
          verbose = verbose
        )
        srt_list[[i]] <- Signac::RunTFIDF(
          object = srt_list[[i]],
          assay = assay,
          verbose = FALSE
        )
      }
      if (normalization_method == "scran") {
        log_message(
          "Perform {.pkg scran} deconvolution normalization on {.val {i}}/{.val {length(srt_list)}} of {.arg srt_list}...",
          verbose = verbose
        )
        srt_list[[i]] <- normalize_scran_seurat(
          srt = srt_list[[i]],
          assay = assay,
          verbose = verbose
        )
      }
    }

    if (is.null(HVF)) {
      if (
        isTRUE(do_HVF_finding) ||
          is.null(do_HVF_finding) ||
          length(SeuratObject::VariableFeatures(srt_list[[i]], assay = assay)) == 0
      ) {
        if (type == "RNA" && HVF_method != "scran") {
          log_message(
            "Perform {.fn FindVariableFeatures} on {.val {i}}/{.val {length(srt_list)}} of {.arg srt_list}...",
            verbose = verbose
          )
          srt_list[[i]] <- if (identical(HVF_method, "vst")) {
            FindVariableFeatures(
              srt_list[[i]],
              assay = assay,
              nfeatures = nHVF,
              selection.method = HVF_method,
              verbose = FALSE
            )
          } else {
            FindVariableFeatures(
              srt_list[[i]],
              assay = assay,
              nfeatures = nHVF,
              selection.method = HVF_method,
              verbose = FALSE
            )
          }
        }
        if (type == "RNA" && HVF_method == "scran") {
          log_message(
            "Perform {.pkg scran} highly variable feature selection on {.val {i}}/{.val {length(srt_list)}} of {.arg srt_list}...",
            verbose = verbose
          )
          hvf_res <- find_hvf_scran_seurat(
            srt = srt_list[[i]],
            assay = assay,
            nHVF = nHVF,
            verbose = verbose
          )
          srt_list[[i]] <- hvf_res[["srt"]]
          SeuratObject::VariableFeatures(srt_list[[i]], assay = assay) <- hvf_res[["HVF"]]
        }
        if (type == "Chromatin") {
          log_message(
            "Perform {.fn FindTopFeatures} on {.val {i}}/{.val {length(srt_list)}} of {.arg srt_list}...",
            verbose = verbose
          )
          srt_list[[i]] <- Signac::FindTopFeatures(
            srt_list[[i]],
            assay = assay,
            min.cutoff = "q5",
            verbose = FALSE
          )
        }
      }
    }

    if (normalization_method == "SCT" && type == "RNA") {
      check_r("glmGamPoi", verbose = FALSE)
      if (
        isTRUE(do_normalization) ||
          isTRUE(do_HVF_finding) ||
          !"SCT" %in% SeuratObject::Assays(srt_list[[i]])
      ) {
        log_message(
          "Perform {.fn Seurat::SCTransform} on {.val {i}}/{.val {length(srt_list)}} of {.arg srt_list}...",
          verbose = verbose
        )
        srt_list[[i]] <- Seurat::SCTransform(
          object = srt_list[[i]],
          variable.features.n = nHVF,
          vars.to.regress = vars_to_regress,
          assay = assay,
          new.assay.name = "SCT",
          verbose = FALSE
        )
      } else {
        SeuratObject::DefaultAssay(srt_list[[i]]) <- "SCT"
      }
      sct_assay <- srt_list[[i]][["SCT"]]
      if (length(sct_assay@SCTModel.list) == 1L) {
        feature_attr_sct <- GetFeaturesData(srt_list[[i]], assay = "SCT")
        if (!"residual_variance" %in% colnames(feature_attr_sct)) {
          feature_attr_sct <- Seurat::SCTResults(
            object = sct_assay,
            slot = "feature.attributes"
          )
        }
        nfeatures <- min(nHVF, nrow(x = feature_attr_sct))
        top_features <- rownames(x = feature_attr_sct)[utils::head(
          order(feature_attr_sct$residual_variance, decreasing = TRUE),
          n = nfeatures
        )]
        SeuratObject::VariableFeatures(srt_list[[i]], assay = "SCT") <- top_features
        srt_list[[i]] <- AddFeaturesData(
          srt_list[[i]],
          features = feature_attr_sct,
          assay = "SCT"
        )
      } else {
        top_features <- if (utils::packageVersion("Seurat") >= "5.1.0") {
          Seurat::SelectSCTIntegrationFeatures(srt_list[[i]], assay = "SCT", nfeatures = nHVF, verbose = FALSE)
        } else {
          SeuratObject::VariableFeatures(sct_assay, nfeatures = nHVF)
        }
        SeuratObject::VariableFeatures(srt_list[[i]], assay = "SCT") <- top_features
      }
    }
  }

  if (is.null(HVF)) {
    if (HVF_source == "global") {
      log_message(
        "Use the global HVF from merged dataset",
        verbose = verbose
      )
      srt_merge <- Reduce(merge, srt_list)
      if (type == "RNA") {
        if (HVF_method == "scran") {
          hvf_res <- find_hvf_scran_seurat(
            srt = srt_merge,
            assay = SeuratObject::DefaultAssay(srt_merge),
            nHVF = nHVF,
            verbose = verbose
          )
          HVF <- hvf_res[["HVF"]]
        } else {
          srt_merge <- if (identical(HVF_method, "vst")) {
            FindVariableFeatures(
              srt_merge,
              assay = SeuratObject::DefaultAssay(srt_merge),
              nfeatures = nHVF,
              selection.method = HVF_method,
              verbose = FALSE
            )
          } else {
            FindVariableFeatures(
              srt_merge,
              assay = SeuratObject::DefaultAssay(srt_merge),
              nfeatures = nHVF,
              selection.method = HVF_method,
              verbose = FALSE
            )
          }
          HVF <- SeuratObject::VariableFeatures(srt_merge)
        }
      }
      if (type == "Chromatin") {
        srt_merge <- Signac::FindTopFeatures(
          srt_merge,
          assay = SeuratObject::DefaultAssay(srt_merge),
          min.cutoff = "q5",
          verbose = FALSE
        )
        HVF <- SeuratObject::VariableFeatures(srt_merge)
      }
    }
    if (HVF_source == "separate") {
      log_message(
        "Use the separate HVF from {.arg srt_list}",
        verbose = verbose
      )
      HVF_sort <- sort(
        table(unlist(lapply(srt_list, SeuratObject::VariableFeatures))),
        decreasing = TRUE
      )
      HVF_filter <- HVF_sort[HVF_sort >= HVF_min_intersection]
      if (type == "RNA") {
        if (HVF_method == "scran") {
          HVF <- names(utils::head(HVF_filter, n = nHVF %||% length(HVF_filter)))
        } else {
          HVF <- SelectIntegrationFeatures(
            object.list = srt_list,
            nfeatures = nHVF,
            verbose = FALSE
          )
          HVF <- intersect(HVF, names(HVF_filter))
        }
      }
      if (type == "Chromatin") {
        nHVF_use <- min(
          nHVF,
          min(sapply(
            srt_list,
            function(srt) length(SeuratObject::VariableFeatures(srt))
          ))
        )
        HVF <- names(utils::head(HVF_filter, nHVF_use))
      }
      if (length(HVF) == 0) {
        log_message(
          "No HVF available",
          message_type = "error"
        )
      }
    }
  } else {
    cf <- Reduce(
      intersect,
      lapply(srt_list, function(srt) {
        rownames(
          GetAssayData5(
            srt,
            layer = "counts",
            assay = SeuratObject::DefaultAssay(srt)
          )
        )
      })
    )
    HVF <- HVF[HVF %in% cf]
  }
  if (normalization_method == "SCT" && type == "RNA") {
    model_features <- lapply(srt_list, function(srt) {
      Reduce(intersect, lapply(srt[["SCT"]]@SCTModel.list, function(model) {
        rownames(Seurat::SCTResults(model, slot = "feature.attributes"))
      }))
    })
    HVF <- intersect(HVF, Reduce(intersect, model_features))
    if (length(HVF) == 0L) {
      log_message("No HVF available in every SCT model", message_type = "error")
    }
  }
  log_message(
    "Number of available HVF: {.val {length(HVF)}}",
    verbose = verbose
  )

  hvf_sum <- lapply(srt_list, function(srt) {
    Matrix::colSums(
      GetAssayData5(
        srt,
        layer = "counts",
        assay = SeuratObject::DefaultAssay(srt)
      )[
        HVF, ,
        drop = FALSE
      ]
    )
  })
  cell_all <- unlist(unname(hvf_sum))
  cell_abnormal <- names(cell_all)[cell_all == 0]
  if (length(cell_abnormal) > 0) {
    log_message(
      "Some cells do not express any of the highly variable features: {.val {cell_abnormal}}",
      message_type = "warning",
      verbose = verbose
    )
  }

  if (normalization_method == "SCT" && type == "RNA") {
    srt_list <- lapply(srt_list, get_sct_residuals, features = HVF)
    srt_list <- Seurat::PrepSCTIntegration(
      object.list = srt_list,
      anchor.features = HVF,
      assay = "SCT",
      verbose = FALSE
    )
  }
  log_message(
    "Finished check",
    verbose = verbose
  )

  return(
    list(
      srt_list = srt_list,
      HVF = HVF,
      assay = assay,
      type = type
    )
  )
}

normalize_scran_seurat <- function(
  srt,
  assay,
  verbose = TRUE
) {
  check_r(c("scran", "scuttle"), verbose = FALSE)
  sce <- Seurat::as.SingleCellExperiment(srt, assay = assay)
  clusters <- scran::quickCluster(
    sce,
    min.size = min(100L, ncol(sce))
  )
  sce <- scran::computeSumFactors(sce, clusters = clusters)
  sce <- scuttle::logNormCounts(sce)
  logcounts <- SummarizedExperiment::assay(sce, "logcounts")
  srt <- SeuratObject::SetAssayData(
    object = srt,
    assay = assay,
    layer = "data",
    new.data = logcounts
  )
  size_factors <- SingleCellExperiment::sizeFactors(sce)
  names(size_factors) <- colnames(srt)
  srt[["scran_size_factor"]] <- size_factors
  log_message(
    "{.pkg scran} normalization completed",
    message_type = "success",
    verbose = verbose
  )
  return(srt)
}

find_hvf_scran_seurat <- function(
  srt,
  assay,
  nHVF = 2000,
  verbose = TRUE
) {
  check_r(c("scran", "scuttle"), verbose = FALSE)
  sce <- Seurat::as.SingleCellExperiment(srt, assay = assay)
  if (!"logcounts" %in% SummarizedExperiment::assayNames(sce)) {
    logcounts <- tryCatch(
      GetAssayData5(srt, layer = "data", assay = assay),
      error = function(e) NULL
    )
    if (is.null(logcounts) || nrow(logcounts) == 0 || ncol(logcounts) == 0) {
      sce <- scuttle::logNormCounts(sce)
    } else {
      SummarizedExperiment::assay(sce, "logcounts") <- logcounts
    }
  }
  dec <- scran::modelGeneVar(sce)
  if (is.null(nHVF)) {
    HVF <- scran::getTopHVGs(dec, var.threshold = 0)
  } else {
    HVF <- scran::getTopHVGs(dec, n = min(nHVF, nrow(dec)))
  }
  dec_df <- as.data.frame(dec)
  colnames(dec_df) <- paste0("scran_", colnames(dec_df))
  feature_data <- GetFeaturesData(srt, assay = assay)
  feature_data <- feature_data[, setdiff(colnames(feature_data), colnames(dec_df)), drop = FALSE]
  feature_data <- cbind(feature_data, dec_df[rownames(feature_data), , drop = FALSE])
  srt <- AddFeaturesData(
    object = srt,
    features = feature_data,
    assay = assay
  )
  log_message(
    "{.pkg scran} selected {.val {length(HVF)}} highly variable feature{?s}",
    message_type = "success",
    verbose = verbose
  )
  return(
    list(
      srt = srt,
      HVF = HVF,
      stats = dec
    )
  )
}

#' @title Check and preprocess a merged seurat object
#'
#' @description
#' Checks and preprocesses a merged seurat object.
#'
#' @inheritParams CheckDataList
#' @inheritParams RunIntegration
#' @param srt_merge A merged `Seurat` object that includes the batch information.
#'
#' @seealso [CheckDataList]
#'
#' @export
CheckDataMerge <- function(
  srt_merge,
  batch = NULL,
  assay = NULL,
  do_normalization = NULL,
  normalization_method = "LogNormalize",
  do_HVF_finding = TRUE,
  HVF_source = "separate",
  HVF_method = "vst",
  nHVF = 2000,
  HVF_min_intersection = 1,
  HVF = NULL,
  vars_to_regress = NULL,
  verbose = TRUE,
  seed = 11
) {
  if (!inherits(srt_merge, "Seurat")) {
    log_message(
      "{.arg srt_merge} is not a {.cls Seurat}",
      message_type = "error"
    )
  }
  if (length(batch) != 1) {
    log_message(
      "{.arg batch} must be provided to specify the batch column in meta.data",
      message_type = "error"
    )
  }
  if (!batch %in% colnames(srt_merge@meta.data)) {
    log_message(
      "No batch column: {.val {batch}} found in the meta.data",
      message_type = "error"
    )
  }
  if (!is.factor(srt_merge[[batch, drop = TRUE]])) {
    srt_merge[[batch, drop = TRUE]] <- factor(
      srt_merge[[batch, drop = TRUE]],
      levels = unique(srt_merge[[batch, drop = TRUE]])
    )
  }
  assay <- assay %||% SeuratObject::DefaultAssay(srt_merge)
  srt_merge_raw <- srt_merge
  reuse_log_normalized_merge <- is.null(vars_to_regress) &&
    !isTRUE(do_normalization) &&
    identical(normalization_method, "LogNormalize") &&
    identical(
      suppressWarnings(CheckDataType(
        srt_merge_raw,
        layer = "data",
        assay = assay,
        verbose = FALSE
      )),
      "log_normalized_counts"
    )

  log_message(
    "Split {.arg srt_merge} into {.arg srt_list} by {.val {batch}}",
    verbose = verbose
  )
  srt_list <- Seurat::SplitObject(
    object = srt_merge_raw,
    split.by = batch
  )

  checked <- CheckDataList(
    srt_list = srt_list,
    batch = batch,
    assay = assay,
    do_normalization = do_normalization,
    do_HVF_finding = do_HVF_finding,
    normalization_method = normalization_method,
    HVF_source = HVF_source,
    HVF_method = HVF_method,
    nHVF = nHVF,
    HVF_min_intersection = HVF_min_intersection,
    HVF = HVF,
    vars_to_regress = vars_to_regress,
    seed = seed
  )
  srt_list <- checked[["srt_list"]]
  HVF <- checked[["HVF"]]
  assay <- checked[["assay"]]
  type <- checked[["type"]]
  if (isTRUE(reuse_log_normalized_merge) && identical(type, "RNA")) {
    srt_merge <- srt_merge_raw
  } else {
    srt_merge <- Reduce(merge, srt_list)
  }
  if (type == "Chromatin") {
    assay_obj <- Seurat::GetAssay(srt_merge, assay = assay)
    feature_order <- rownames(assay_obj@counts)
    if (
      nrow(assay_obj@data) > 0 &&
        setequal(rownames(assay_obj@data), feature_order) &&
        !identical(rownames(assay_obj@data), feature_order)
    ) {
      assay_obj@data <- assay_obj@data[feature_order, , drop = FALSE]
    }
    if (
      nrow(assay_obj@scale.data) > 0 &&
        setequal(rownames(assay_obj@scale.data), feature_order) &&
        !identical(rownames(assay_obj@scale.data), feature_order)
    ) {
      assay_obj@scale.data <- assay_obj@scale.data[feature_order, , drop = FALSE]
    }
    if (
      nrow(assay_obj@meta.features) > 0 &&
        setequal(rownames(assay_obj@meta.features), feature_order) &&
        !identical(rownames(assay_obj@meta.features), feature_order)
    ) {
      assay_obj@meta.features <- assay_obj@meta.features[feature_order, , drop = FALSE]
    }
    srt_merge[[assay]] <- assay_obj
  }

  srt_merge <- srt_append(
    srt_raw = srt_merge,
    srt_append = srt_merge_raw,
    pattern = "",
    slots = "reductions",
    overwrite = TRUE,
    verbose = FALSE
  )
  if (normalization_method == "SCT" && type == "RNA") {
    SeuratObject::DefaultAssay(srt_merge) <- "SCT"
  } else {
    SeuratObject::DefaultAssay(srt_merge) <- assay
  }
  SeuratObject::VariableFeatures(srt_merge) <- HVF

  return(
    list(
      srt_merge = srt_merge,
      srt_list = srt_list,
      HVF = HVF,
      assay = assay,
      type = type
    )
  )
}


get_sct_residuals <- function(object, features, assay = "SCT") {
  if (all(features %in% rownames(GetAssayData5(object, assay = assay, layer = "scale.data")))) {
    return(object)
  }
  umi_names <- unique(unlist(Seurat::SCTResults(object[[assay]], slot = "umi.assay"), use.names = FALSE))
  if (length(umi_names) != 1L) {
    log_message("SCT models must share one UMI assay to compute residuals", message_type = "error")
  }
  umi_assays <- stats::setNames(lapply(umi_names, function(assay) object[[assay]]), umi_names)
  for (umi_assay in umi_names) {
    if (inherits(object[[umi_assay]], "Assay5")) {
      suppressWarnings(object[[umi_assay]] <- SeuratObject::CreateAssayObject(counts = GetAssayData5(object, assay = umi_assay, layer = "counts")))
    }
  }
  object <- Seurat::GetResidual(object, assay = assay, umi.assay = umi_names[[1L]], features = features, verbose = FALSE)
  for (umi_assay in umi_names) {
    object[[umi_assay]] <- umi_assays[[umi_assay]]
  }
  object
}
